<?php
// mailer.php

require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/PHPMailer/src/Exception.php';
require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function _getBaseHtml($title, $subtitle, $contentHtml) {
    return '
    <div style="font-family: \'Inter\', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; border: 1px solid #f1f5f9; box-shadow: 0 10px 25px rgba(0,0,0,0.05);">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #7c3aed, #4f46e5); padding: 40px 20px; text-align: center;">
            <h1 style="color: #ffffff; font-size: 28px; margin: 0; font-weight: 900; letter-spacing: 2px; text-align: center;">DOMATION</h1>
            <p style="color: rgba(255,255,255,0.9); font-size: 13px; margin: 8px 0 0; letter-spacing: 1px; text-transform: uppercase; font-weight: 600;">Hệ Thống Phân Bổ Data Tự Động</p>
        </div>
        <!-- Content -->
        <div style="padding: 40px 30px;">
            <h2 style="color: #0f172a; font-size: 22px; margin-top: 0; margin-bottom: 24px;">' . $title . '</h2>
            ' . $contentHtml . '
        </div>
        <!-- Footer -->
        <div style="background-color: #0f172a; padding: 20px; text-align: center;">
            <p style="color: #94a3b8; font-size: 12px; margin: 0; line-height: 1.6;">
                © 2026 Domation Ecosystem. All rights reserved.<br/>
                Email này được gửi tự động từ hệ thống quản trị DOMATION.
            </p>
        </div>
    </div>
    ';
}

function sendEmailNotification($to, $subject, $title, $content, $ccEmailString = '') {
    global $conn;
    
    // Fetch settings
    $res = $conn->query("SELECT * FROM system_settings");
    $settings = [];
    while($row = $res->fetch_assoc()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    $provider = $settings['email_provider'] ?? 'appscript';

    $htmlBody = _getBaseHtml($title, "", $content);

    if ($provider === 'appscript') {
        $url = $settings['appscript_webhook_url'] ?? '';
        if (empty($url)) return false;

        $payload = json_encode([
            "type" => "custom",
            "email" => $to,
            "cc" => $ccEmailString,
            "subject" => $subject,
            "htmlBody" => $htmlBody
        ]);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);
        return true;
    } else if ($provider === 'ses') {
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = $settings['ses_host'] ?? '';
            $mail->SMTPAuth   = true;
            $mail->Username   = $settings['ses_username'] ?? '';
            $mail->Password   = $settings['ses_password'] ?? '';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;
            $mail->CharSet    = 'UTF-8';

            $senderEmail = $settings['ses_sender_email'] ?? 'no-reply@domation.net';
            $senderName = $settings['ses_sender_name'] ?? 'DOMATION TEAM';
            
            $mail->setFrom($senderEmail, $senderName);
            $mail->addAddress($to);
            
            if (!empty($ccEmailString)) {
                $ccList = explode(',', $ccEmailString);
                foreach ($ccList as $cc) {
                    $cc = trim($cc);
                    if (!empty($cc) && filter_var($cc, FILTER_VALIDATE_EMAIL)) {
                        $mail->addCC($cc);
                    }
                }
            }

            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;

            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
            return false;
        }
    }
    return false;
}

function sendLeadAssignedEmailToSale($consultantEmail, $consultantName, $leadName, $leadPhone, $ccEmailString = '') {
    $subject = "DOMATION - Bạn có 1 Data mới được phân bổ!";
    $content = '
        <p style="color: #475569; font-size: 16px; line-height: 1.7; margin-bottom: 24px;">
            Chào <strong>' . htmlspecialchars($consultantName) . '</strong>,<br><br>
            Hệ thống vừa phân bổ tự động cho bạn 1 khách hàng mới từ chiến dịch Inbound.
        </p>
        
        <div style="background-color: #f8fafc; border-left: 4px solid #7c3aed; padding: 24px; margin: 30px 0; border-radius: 0 12px 12px 0;">
            <p style="color: #0f172a; font-size: 16px; margin: 0 0 10px 0; font-weight: bold; line-height: 1.6;">
                Thông tin Khách hàng:
            </p>
            <ul style="color: #334155; font-size: 15px; margin: 0; padding-left: 20px; line-height: 1.8;">
                <li>Tên Khách Hàng: <strong style="color: #0f172a;">' . htmlspecialchars($leadName) . '</strong></li>
                <li>Số điện thoại: <strong style="color: #2563eb;">' . htmlspecialchars($leadPhone) . '</strong></li>
                <li>Trạng thái: <strong style="color: #ef4444;">Chưa tư vấn</strong></li>
            </ul>
        </div>
        
        <p style="color: #64748b; font-size: 15px; line-height: 1.7;">
            Vui lòng nhanh chóng liên hệ với khách hàng để đảm bảo tỷ lệ chốt Sales cao nhất nhé!
        </p>
        
        <div style="text-align: center; margin-top: 40px;">
            <a href="https://open.domation.net/sale_data/" target="_blank" style="background-color: #7c3aed; background-image: linear-gradient(to right, #7c3aed, #4f46e5); color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: bold; display: inline-block; font-size: 16px; box-shadow: 0 4px 6px rgba(124,58,237,0.3);">
                Đăng nhập CRM
            </a>
        </div>
    ';
    
    sendEmailNotification($consultantEmail, $subject, "Có Data Mới Về!", $content, $ccEmailString);
}

